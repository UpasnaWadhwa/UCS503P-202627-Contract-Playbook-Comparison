# Week 1 : <Title of the issue/topic you worked on>

## Error / Issue
> Paste the exact error message, warning, or the problem statement you ran into here.

## Relevant Context
Describe what you were doing when this came up — what file, command, config,
or design decision led to it. Include a minimal code/command snippet if useful.

``` shell
# example command or config
```

## Key Observation
What did you notice that pointed you toward the cause? What did you rule out
first, and what made you suspect the actual cause?

## Solution
Describe the fix or decision you made.

``` shell
# example fix
```

**Because**
Explain *why* the fix works — the underlying principle, not just the patch.
