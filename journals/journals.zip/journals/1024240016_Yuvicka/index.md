# Yuvicka's Journal
Roll No. 1024240016
Name: Yuvicka

+ [W1 : Week 1 Title Here](./week1.md)
+ [...]
